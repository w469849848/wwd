$(document).ready(function(){
			$('.shop-line1').click(function(){
				$('.select-shop-img1').toggleClass('select-shop-img5')
			})

			$('.shop-line3').click(function(){
				$('.select-shop-img2').toggleClass('select-shop-img6')
			})

			$('.shop-line4').click(function(){
				$('.select-shop-img3').toggleClass('select-shop-img7')
			})

			$('.shop-line2').click(function(){
				$('.select-shop-img4').toggleClass('select-shop-img8')
			})
		});